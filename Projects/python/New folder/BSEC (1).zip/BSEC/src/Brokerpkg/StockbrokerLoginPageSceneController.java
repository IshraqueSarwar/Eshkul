/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package Brokerpkg;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;


public class StockbrokerLoginPageSceneController implements Initializable {

    @FXML
    private TextField stockbrokerIdTextField;
    @FXML
    private TextField stockbrokerPasswordTextField;


    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    

    @FXML
    private void loginButtonOnClick(ActionEvent event) {
    }

    @FXML
    private void signUpButtonOnClick(ActionEvent event) {
    }
    
}
